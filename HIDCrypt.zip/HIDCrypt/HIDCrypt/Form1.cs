﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HIDCrypt
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void openFileDialog2_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] args = Environment.GetCommandLineArgs();
            if (args.Length > 1)
            {
                string filePath = args[1];

                // Read the encrypted bytes from the file
                byte[] encryptedBytes = File.ReadAllBytes(filePath);

                // Decrypt the bytes using AES decryption
                string password = "HIDDECRYPT"; // Replace with the same secure password used for encryption
                string decryptedText = DecryptStringFromBytes_Aes(encryptedBytes, password);

                // Populate TextBox1 with the decrypted text
                textBox1.Text = decryptedText;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string filePath = Path.Combine(desktopPath, "EncryptedTextFile.hid");

            // Encrypt the text using AES encryption
            string textToEncrypt = textBox1.Text;
            string password = "HIDDECRYPT"; // Replace with a secure password
            byte[] encryptedBytes = EncryptStringToBytes_Aes(textToEncrypt, password);

            // Save the encrypted bytes to the file
            File.WriteAllBytes(filePath, encryptedBytes);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Hidden Files (*.hid)|*.hid";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;

                // Read the encrypted bytes from the file
                byte[] encryptedBytes = File.ReadAllBytes(filePath);

                // Decrypt the bytes using AES decryption
                string password = textBox2.Text; // Replace with the same secure password used for encryption
                string decryptedText = DecryptStringFromBytes_Aes(encryptedBytes, password);

                // Populate TextBox1 with the decrypted text
                textBox1.Text = decryptedText;
            }
        }
        static byte[] EncryptStringToBytes_Aes(string plainText, string password)
        {
            byte[] encrypted;
            using (Aes aesAlg = Aes.Create())
            {
                Rfc2898DeriveBytes keyDerivation = new Rfc2898DeriveBytes(password, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                aesAlg.Key = keyDerivation.GetBytes(32);
                aesAlg.IV = keyDerivation.GetBytes(16);

                ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter sw = new StreamWriter(cs))
                        {
                            sw.Write(plainText);
                        }
                        encrypted = ms.ToArray();
                    }
                }
            }
            return encrypted;
        }

        // AES decryption method
        static string DecryptStringFromBytes_Aes(byte[] cipherText, string password)
        {
            string plaintext = null;
            using (Aes aesAlg = Aes.Create())
            {
                Rfc2898DeriveBytes keyDerivation = new Rfc2898DeriveBytes(password, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                aesAlg.Key = keyDerivation.GetBytes(32);
                aesAlg.IV = keyDerivation.GetBytes(16);

                ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

                using (MemoryStream ms = new MemoryStream(cipherText))
                {
                    using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader sr = new StreamReader(cs))
                        {
                            plaintext = sr.ReadToEnd();
                        }
                    }
                }
            }
            return plaintext;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Hidden Files (*.hid)|*.hid";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;

                // Read the encrypted bytes from the file
                byte[] encryptedBytes = File.ReadAllBytes(filePath);

                // Decrypt the bytes using AES decryption
                string password = "HIDDECRYPTT"; // Replace with the same secure password used for encryption
                string decryptedText = DecryptStringFromBytes_Aes(encryptedBytes, password);

                // Populate TextBox1 with the decrypted text
                textBox1.Text = decryptedText;
            }
        }
    }
}
